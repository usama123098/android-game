package com.example.usama.snake_ladder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Home_Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home__screen);
    }

    public void PLAY(View view)
    {
        Intent PLAY_OBJ = new Intent(this,PLAY.class);
        startActivity(PLAY_OBJ);

    }

    public void Help(View view)
    {
        Intent Help_OBJ = new Intent(this,Help.class);
        startActivity(Help_OBJ);

    }

    public void Quit(View view)
    {
        finish();
        System.exit(0);

    }
}
