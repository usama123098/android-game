package com.example.usama.snake_ladder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PLAY extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
    }
}
